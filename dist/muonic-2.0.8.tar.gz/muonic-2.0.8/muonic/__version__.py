__version__ = "2.0.8"
__source_location__ = "https://github.com/achim1/muonic/"
