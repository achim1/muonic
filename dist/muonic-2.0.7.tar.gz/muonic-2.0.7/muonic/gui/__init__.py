"""
The gui of the programm, written with PyQt4
"""




