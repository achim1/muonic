__version__ = "2.0.5"
__source_location__ = "https://github.com/achim1/muonic/"
